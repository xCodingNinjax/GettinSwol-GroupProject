package com.codingdojo.gettinswol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GettinswolApplicationTests {

	@Test
	void contextLoads() {
	}

}
